// Here we have constants for system call tracing
// Functions themselves are in respective header files.

#define T_TRACE 1
#define T_ONFORK 2

#define T_UNTRACE 0
// irli
